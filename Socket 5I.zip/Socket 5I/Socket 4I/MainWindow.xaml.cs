﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;           // librerie per lavorare
using System.Net.Sockets;   // con i socket, ip ecc. (creo applicativi di rete)
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading; // librerie per 
using System.Threading;         // i thread


namespace Socket_4I
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Socket socket = null; //ci appoggiamo alla classe socket (creo un oggetto ma non lo istanzio)
        private Thread controlloBuffer = null;
        private bool inEsecuzione = true;

        //DispatcherTimer dTimer = null; //trasmissione asincrona (non so quando mi arriverà un mess.)
        //utilizzo un timer, alla fine di esso, vado a leggere nel buffer se è presente qualcosa
        //per migliorare si può aggiugere un thread che processa il buffer sempre non appena viene riempito
        //tolto per utilizzo dei thread
        public MainWindow()
        {
            InitializeComponent();

            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                    // creo l'oggetto         IPv4         lavoro con datagram    utilizzo UDP
            IPAddress local_address = IPAddress.Any;  //recupera l'IP della macchina
            IPEndPoint local_endpoint = new IPEndPoint(local_address, 50000); //definisco le info socket (con ip e porta)

            socket.Bind(local_endpoint); //collega le informazioni dell'endpoint al socket 

            /* USELESS
            socket.Blocking = false;
            socket.EnableBroadcast = true; 
            */ //USELESS


            /*dTimer = new DispatcherTimer(); //creo il timer

            dTimer.Tick += new EventHandler(aggiornamento_dTimer); //ogni volte che finisce il timer richiama il metodo
            dTimer.Interval = new TimeSpan(0, 0, 0, 0, 250); //definisco la dimensione del timer
            dTimer.Start(); //faccio partire il timer*/ //tolto per utilizzo thread


            
            controlloBuffer = new Thread(new ThreadStart(ctrlBuffer)); //creo il thread e gli assegno il metodo che controlla il buffer
            controlloBuffer.IsBackground = true; //gli assegno la proprietà di poter eseguiren in background
            controlloBuffer.Start(); //lo faccio partire
        }

       /*private void aggiornamento_dTimer(object sender, EventArgs e)
        {
            int nBytes = 0;

            if ((nBytes = socket.Available) > 0)  //controlla se è presente qualcosa nel buffer
            {
                //ricezione dei caratteri in attesa
                byte[] buffer = new byte[nBytes]; //creo un array che rappresenta il mio buffer

                EndPoint remoreEndPoint = new IPEndPoint(IPAddress.Any, 0); //creo un oggetto senza valori

                nBytes = socket.ReceiveFrom(buffer, ref remoreEndPoint); //vado a recuperare l'indirizzo ip di colui che mi ha contattato/da chi ho ricevuto

                string from = ((IPEndPoint)remoreEndPoint).Address.ToString();  //recdupero l'indirizzo ip dal socket trasmettitore

                string messaggio = Encoding.UTF8.GetString(buffer, 0, nBytes);  //converto il messaggio da byte a string aUTF8


                lstMessaggi.Items.Add(from+": "+messaggio);

            }
        }*/ //tolto per utilizzo thread

        private void btnInvia_Click(object sender, RoutedEventArgs e)
        {
            IPAddress remote_address = IPAddress.Parse(txtTo.Text);  //prendo l'ip dalla textBox

            IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 60000); //definisco il mio socket per la trasmissione

            byte[] messaggio = Encoding.UTF8.GetBytes(txtMessaggio.Text);  //codifico il messaggio in byte

            socket.SendTo(messaggio, remote_endpoint); //invio il messaggio
        }

        private void ctrlBuffer()
        {
            while (inEsecuzione)
            {
                try
                {
                    if (socket.Available > 0)
                    {
                        byte[] buffer = new byte[1024];
                        EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);
                        int nBytes = socket.ReceiveFrom(buffer, ref remoteEndPoint);

                        string from = ((IPEndPoint)remoteEndPoint).Address.ToString();
                        string message = Encoding.UTF8.GetString(buffer, 0, nBytes);

                        // Aggiornamento della UI deve essere fatto sul thread della UI
                        Dispatcher.Invoke(() => lstMessaggi.Items.Add(from + ": " + message)); //metodo lambda che mi forma la stringa nel medoto che spedisce il messaggio nella lista
                        //Dispatcher.Invoke mi gestisce le chiamate sincrone
                    }

                    else
                    {
                        Thread.Sleep(25); // Sleep per evitare il deadlock o sovrautilizzare la CPU
                    }
                }
                catch (SocketException ex)
                {
                    // Gestione delle eccezioni socket
                    Dispatcher.Invoke(() => lstMessaggi.Items.Add("Errore: " + ex.Message));
                    //utilizzo un try & catch in caso si prsenti un errore nel buffer in caso di un problema di trasmissione
                }
            }
        }

        
    }
}
